import React from "react";
import { Button,Navbar,Nav } from "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.min.css'; 
import './Datapage.css';
import { useHistory } from 'react-router-dom';
import {table} from 'react-bootstrap';
import Nextpage from "./Nextpage";


export default function Datapage(){
    console.log('datapage..')
    let history =useHistory();
    return(
     <div>
        <div className="Testing">
        <Button variant="danger" onClick={() =>{history.push('/')}}>LOGOUT</Button>  
        <Button variant="success" onClick={()=>{history.push('/Nextpage')}}> Next Page</Button>
        </div>
        
        

        <table className="tb table table-bordered">
            <thead>
                <tr>
                    <th scope='col'>ID</th>
                    <th scope='col'>NAME</th>
                    <th scope='col'>AGE</th>
                    <th scope='col'>GENDER</th>
                    <th scope='col'>EMAIL</th>
                    <th scope='col'>PHONE NO</th>
                </tr>

            </thead>
            <tbody>
                <tr>
                    <th scope="row">1</th>
                    <td>shiva</td>
                    <td>21</td>
                    <td>male</td>
                    <td>sivavoota437@gmail.com</td>
                    <td>9703056535</td>
                </tr>
                <tr>
                    <th scope="row">2</th>
                    <td>swamy</td>
                    <td>21</td>
                    <td>male</td>
                    <td>swamy21@gmail.com</td>
                    <td>7286575351</td>
                </tr>
                <tr>
                    <th scope="row">3</th>
                    <td>sharuna</td>
                    <td>20</td>
                    <td>male</td>
                    <td>sharuna@gmail.com</td>
                    <td>9122319231</td>
                </tr>
            </tbody>
        </table>
       
     </div>

    )
};