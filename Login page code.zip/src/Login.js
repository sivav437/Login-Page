import 'bootstrap/dist/css/bootstrap.min.css'; //for styling bootstrap element
import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';

import './Login.css';
import { Form, Button } from 'react-bootstrap'; //importing button component from bootstrap



export default function Login(){
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  let history =useHistory();

  const handleSubmit = (event) => {
    event.preventDefault();
    

    if (event.target.checkValidity()) {
      setIsLoggedIn(true);
    };
    if (email==='shivalucky821@gmail.com' && password==='Shiva@437') {
         
         alert("login success..");
         console.log('opened...');
         history.push('/Datapage');
         
       }else{
         alert('sorry...you dont have login aceess')
       }
    setEmail("");
    setPassword("");
   //setItem({password:"", email:""}); //making empty
  
}

  const [showpassword,setShowpassword]=useState(false);
  function handleTogglepassword(){
       setShowpassword(!showpassword)
  }
  return (
    <Form onSubmit={handleSubmit}>
      <Form.Group controlId="formBasicPassword">
        <Form.Label>Email</Form.Label>
        <Form.Control 
             type="email"
             name="email"
             placeholder='enter user email'
             required
             value={email}
             onChange={(event) => setEmail(event.target.value)}
         >

        </Form.Control>
        <Form.Label>Password</Form.Label>
        <Form.Control
          type={showpassword?'text':'password'}
          name="password"
          placeholder="Password"
          minLength="8" //optional
          pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W).{8,}"
          required
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          //onChange={changehandle}
        />
        <Form.Check className='checkstyle'
          type ="checkbox"
          label="show password"
          onChange={handleTogglepassword}
          ></Form.Check>
  
        
        <Form.Control.Feedback type="invalid">
          Please enter a valid password with at least one uppercase letter, one lowercase letter, one number, and one special character.
        </Form.Control.Feedback>
      </Form.Group>

      <Button className="Btn" variant="primary" type="submit">
        Submit
      </Button>
    </Form>
  

      
  );


}