import React from "react";
import { Button } from "react-bootstrap";
import './Datapage.css';
import { useHistory } from "react-router-dom";
function Nextpage(){
    let history =useHistory();

    return(
    <div className="Testing">
        <h1 classNmae="headSec">Nextpage</h1>
        <h2>welcome text</h2>
        <Button onClick={() =>{history.push('/Datapage')}}>Back</Button>
        

    </div>
    );
}

export default Nextpage;