
import './App.css';
import React, { useState } from 'react';
import Datapage from './Datapage';
import Nextpage from './Nextpage';
import './Login.css';
import Login from './Login';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';



function App() {
  
      return(
        <Router>
          <Switch>
        <Route exact path="/" component={Login} />
         
          <Route path="/Datapage" component={Datapage} /> 
          <Route path="/Nextpage" component={Nextpage} />
          </Switch>
         
       
    </Router>
      );

}

export default App;
